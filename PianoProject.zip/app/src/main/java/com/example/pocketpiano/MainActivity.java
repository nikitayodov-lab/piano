package com.example.pocketpiano;
import android.app.Activity;
import android.os.Bundle;
import android.media.*;
import android.view.*;
import android.graphics.*;
import android.util.SparseIntArray;
import java.util.*;

public class MainActivity extends Activity {
 SoundPool pool;
 int[] sounds=new int[25];
 volatile int loaded=0;
 Piano piano;
 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  setVolumeControlStream(AudioManager.STREAM_MUSIC);
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  pool=new SoundPool.Builder().setMaxStreams(24).setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()).build();
  piano=new Piano(); setContentView(piano);
  pool.setOnLoadCompleteListener((p,id,status)->{if(status==0)loaded++;piano.postInvalidate();});
  for(int i=0;i<25;i++){
   int r=getResources().getIdentifier("note"+(48+i),"raw",getPackageName());
   sounds[i]=pool.load(this,r,1);
  }
 }
 @Override protected void onPause(){super.onPause();if(piano!=null)piano.stopAll();pool.autoPause();}
 @Override protected void onResume(){super.onResume();if(pool!=null)pool.autoResume();}
 @Override protected void onDestroy(){pool.release();super.onDestroy();}
 class Piano extends View {
  Paint paint=new Paint(3);
  int[] whites={0,2,4,5,7,9,11,12};
  int[] blacks={1,3,6,8,10}, edges={1,2,4,5,6};
  RectF[] keys=new RectF[13];
  SparseIntArray fingerNotes=new SparseIntArray(),streams=new SparseIntArray();
  int octave=4; float volume=.7f;
  Piano(){super(MainActivity.this);setBackgroundColor(Color.rgb(18,21,34));}
  void text(Canvas c,String s,float x,float y,float size,int color){paint.setColor(color);paint.setTextSize(size);paint.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,paint);}
  @Override protected void onSizeChanged(int w,int h,int ow,int oh){
   float kw=(w-32f)/8,top=h*.36f;
   for(int i=0;i<8;i++)keys[whites[i]]=new RectF(16+i*kw,top,16+(i+1)*kw,h-16);
   for(int i=0;i<5;i++)keys[blacks[i]]=new RectF(16+(edges[i]-.3f)*kw,top,16+(edges[i]+.3f)*kw,top+(h-16-top)*.62f);
  }
  boolean pressed(int note){for(int i=0;i<fingerNotes.size();i++)if(fingerNotes.valueAt(i)==note)return true;return false;}
  @Override protected void onDraw(Canvas c){
   float w=getWidth(),h=getHeight(),sz=Math.min(h*.065f,w*.036f);
   text(c,"МОЁ ПИАНИНО",w/2,h*.10f,sz,Color.WHITE);
   String[] labels={"Октава −","Октава +","Тише","Громче"};
   for(int i=0;i<4;i++){paint.setColor(Color.rgb(48,54,78));c.drawRoundRect(new RectF(i*w/4+8,h*.14f,(i+1)*w/4-8,h*.25f),12,12,paint);text(c,labels[i],(i+.5f)*w/4,h*.215f,sz*.66f,Color.WHITE);}
   text(c,loaded<25?"Загрузка звуков: "+loaded+"/25":"Октава "+octave+"  •  Громкость "+Math.round(volume*100)+"%",w/2,h*.315f,sz*.6f,Color.LTGRAY);
   String[] names={"До","Ре","Ми","Фа","Соль","Ля","Си","До"};
   for(int i=0;i<8;i++){int n=whites[i];paint.setColor(pressed(n)?0xffb79aec:0xffedf0f7);c.drawRoundRect(keys[n],6,6,paint);paint.setStyle(Paint.Style.STROKE);paint.setColor(0xff363a50);c.drawRoundRect(keys[n],6,6,paint);paint.setStyle(Paint.Style.FILL);text(c,names[i],keys[n].centerX(),h-32,sz*.55f,0xff44485c);}
   for(int n:blacks){paint.setColor(pressed(n)?0xff8059be:0xff202232);c.drawRoundRect(keys[n],6,6,paint);}
  }
  int hit(float x,float y){for(int n:blacks)if(keys[n].contains(x,y))return n;for(int n:whites)if(keys[n].contains(x,y))return n;return -1;}
  void stop(int id){int stream=streams.get(id,0);if(stream!=0)pool.stop(stream);streams.delete(id);fingerNotes.delete(id);}
  void stopAll(){for(int i=0;i<streams.size();i++)pool.stop(streams.valueAt(i));streams.clear();fingerNotes.clear();invalidate();}
  void note(int id,float x,float y){int n=hit(x,y);if(fingerNotes.get(id,-1)==n)return;stop(id);if(n>=0&&loaded==25){int index=(octave-3)*12+n;int stream=pool.play(sounds[index],volume,volume,1,0,1);if(stream!=0){streams.put(id,stream);fingerNotes.put(id,n);}}}
  @Override public boolean onTouchEvent(MotionEvent e){
   int action=e.getActionMasked(),ix=e.getActionIndex(),id=e.getPointerId(ix);
   if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){
    float x=e.getX(ix),y=e.getY(ix);
    if(y>=getHeight()*.14f&&y<=getHeight()*.25f){int b=(int)(x/(getWidth()/4f));stopAll();if(b==0)octave=3;if(b==1)octave=4;if(b==2)volume=Math.max(0,volume-.1f);if(b==3)volume=Math.min(1,volume+.1f);}else note(id,x,y);
   }else if(action==MotionEvent.ACTION_MOVE){for(int i=0;i<e.getPointerCount();i++)note(e.getPointerId(i),e.getX(i),e.getY(i));}
   else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP)stop(id);
   else if(action==MotionEvent.ACTION_CANCEL)stopAll();
   invalidate();return true;
  }
 }
}
